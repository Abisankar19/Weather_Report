<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
 	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
  	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
  	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
	<script type="text/javascript">
		function home(){
			$('#todayWeather').attr('action', 'index');
			$('#todayWeather').submit();
    	}
	</script>
	<?php echo e(Form::open(array('name'=>'todayWeather', 'id'=>'todayWeather','url' => 'Weather_report/currentDayData','files'=>true,'method' => 'POST'))); ?>

   	<?php echo e(csrf_field()); ?>

		<div class="row hline">
		    <div class="col-sm-8">
		    	<title>Weather Report</title>
		        <h1 class="pull-left pl5 mt15">Today Weather Report</h1>
		    </div>
		</div>
		<div class ="text-right" style="width: auto;margin-bottom: 2px;">
			<button onclick="home();" class="btn btn-warning"><span class="glyphicon glyphicon-home"></span>Goto Dashboard</button>
		</div>
		<div class="box100per pr10 pl10 mt16" style="min-height: 250px;">
			<table cellpadding="4" class="table table-striped table-bordered box100per">
				<colgroup>
					<col width="5%">
					<col width="5%">
					<col width="5%">
					<col width="15%">
				</colgroup>
				<thead class="">
					<tr>
						<th class="text-center">Temprature(min)<img class="img-fluid" src="https://img.icons8.com/emoji/96/000000/sun-emoji.png" width="10%" height="10%" /></th>
						<th class="text-center">Temprature(max)<img class="img-fluid" src="https://img.icons8.com/emoji/96/000000/sun-emoji.png" width="10%" height="10%" /></th>
						<th class="text-center">Weather<img class="img-fluid" src="https://cdn.iconscout.com/icon/free/png-512/weather-192-461761.png" width="10%" height="10%" /></th>
						<th class="text-center">Description</th>
					</tr>
				</thead>
				<tbody>
					<?php $i=1; ?> 
			 		<?php if(!empty($list)): ?>
						<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td class="text-center">
								<?php echo e($value["temp_min"]); ?>

							</td>
							<td class="text-center">
								<?php echo e($value["temp_max"]); ?>

							</td>
							<td class="">
								<?php echo e($value["main"]); ?>

							</td>
							<td class="">
								<?php echo e($value["description"]); ?>

							</td>
						</tr>
						<?php $i++; ?> 
						<?php echo e(Form::hidden('cnt', $i , array('id' => 'cnt'))); ?>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
						<tr>
							<td colspan="5" class="text-center fr">No Data Found
							</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
	<?php echo e(Form::close()); ?>

<?php /**PATH C:\Users\Abi\Weather_report\resources\views/todayweather.blade.php ENDPATH**/ ?>