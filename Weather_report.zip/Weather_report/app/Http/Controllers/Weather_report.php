<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

use Session;
class Weather_report extends Controller
{
    public function index(Request $request){
      $location = isset($request->city)?$request->city:'Chennai';
      $apiKey = 'd842afa0cacb6d793389211cb9dfc379';
      $list = array();
      if(isset($location) && $location !='' ){
        $response = Http::get("https://api.openweathermap.org/data/2.5/forecast?q={$location}&cnt=35&appid=d842afa0cacb6d793389211cb9dfc379");
        $json = json_decode($response,true);
        $arr = array();
        $i =0;
        foreach ($json["list"] as $key => $value) {
          $k = "3";
          $list[$i]["temp_min"]  = $value["main"]["temp_min"];
          $list[$i]["temp_max"]  = $value["main"]["temp_max"];
          $list[$i]["pressure"]  = $value["main"]["pressure"];
          $list[$i]["main"]  = $value["weather"][0]["main"];
          $list[$i]["description"]  = $value["weather"][0]["description"];
          $list[$i]["dt_txt"]  = $value["dt_txt"];
          $i++;
        }
      }
      return view('list',[
                  'request' => $request,
                  'list' =>$list
                  ]);
    }

    public function currentDayData(Request $request){
      $location ='1264527';
      $apiKey = 'd842afa0cacb6d793389211cb9dfc379';
      $response = Http::get("http://api.openweathermap.org/data/2.5/weather?q=Chennai&appid=d842afa0cacb6d793389211cb9dfc379");
      $json = json_decode($response,true);
      $arr = array();
      $list = array();
      $i =0;
      $arr[0] =array_merge($json["main"],$json["weather"][0]);
      return view('todayweather',[
                  'request' => $request,
                  'list' =>$arr
                  ]);
    }
}
